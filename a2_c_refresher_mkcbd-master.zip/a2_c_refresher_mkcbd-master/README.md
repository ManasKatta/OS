# A2 - C Refresher
Set 1:

- arrays
- strings
- system programming
- bits

Set 2:

- allocation
- debug
- error_handling
- structures
