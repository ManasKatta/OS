#include "../include/bitmap.h"
#define SetBit(A,k)     ( A[(k/8)] |= (1 << (k%8)) ) 
#define ResetBit(A,k)   (A[k/8] &= ~(1 << (k%8)))
#define TestBit(A,k)    ( A[(k)/8] & (1 << ((k)%8)) )

// data is an array of uint8_t and needs to be allocated in bitmap_create
//      and used in the remaining bitmap functions. You will use data for any bit operations and bit logic
// bit_count the number of requested bits, set in bitmap_create from n_bits
// byte_count the total number of bytes the data contains, set in bitmap_create


bitmap_t *bitmap_create(size_t n_bits)
{
    if(n_bits > 0 && n_bits < SIZE_MAX) /*input validation*/
    {
        bitmap_t *bitmap = (bitmap_t *)malloc(sizeof(bitmap_t));
        if(bitmap == NULL) /*malloc check*/
        {
            return NULL;
        }
        bitmap->bit_count = n_bits;
        bitmap->byte_count = (n_bits / 8) + ((n_bits % 8) != 0);
        bitmap->data = calloc(bitmap->byte_count, sizeof(uint8_t)); /*initialize data to zero as well*/
        return bitmap;
    }
    return NULL;

}

bool bitmap_set(bitmap_t *const bitmap, const size_t bit)
{
    if(bitmap != NULL && bit < bitmap->bit_count)
    {
        SetBit(bitmap->data, bit);
        
        return true;
    }
	return false;
}

bool bitmap_reset(bitmap_t *const bitmap, const size_t bit)
{
    if(bitmap != NULL && bit < bitmap->bit_count)
    {
        ResetBit(bitmap->data, bit);
        
        return true;
    }
	return false;
}

bool bitmap_test(const bitmap_t *const bitmap, const size_t bit)
{ 
    if(bitmap != NULL && bit < bitmap->bit_count)
    {
        int result = TestBit(bitmap->data, bit);
        if(result > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
	return false;

}

size_t bitmap_ffs(const bitmap_t *const bitmap)
{
    if(bitmap != NULL)
    {
        int i;
        for(i=0; i < bitmap->bit_count; i++)
        {
            if(bitmap_test(bitmap, i) == true)
            {
                return i;
            }

        }
        
    }
    return SIZE_MAX;
}

size_t bitmap_ffz(const bitmap_t *const bitmap)
{ 
    if(bitmap != NULL)
    {
        int i;
        for(i=0; i < bitmap->bit_count; i++)
        {
            if(bitmap_test(bitmap, i) == false)
            {
                return i;
            }

        }
        
    }
    return SIZE_MAX;
}

bool bitmap_destroy(bitmap_t *bitmap)
{
    if(bitmap != NULL) /*input validation*/
    {
        if(bitmap->data != NULL)
        {
            free(bitmap->data); /*free data inside bitmap*/
        }
        free(bitmap); /*free bitmap itself*/
        return true;
    }
    return false;
}
