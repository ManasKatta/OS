#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

#include "../include/sstring.h"

bool string_valid(const char *str, const size_t length)
{
    if(str != NULL && length > 0) /*input validation*/
    {
        if(str[length-1] == '\0')
        {
            //printf("String is null terminated");
            return true;
        }
        else
        {
            //printf("String is not null terminated");
            return false;
        }
    }
    else
    {
        return false;
    }

}

char *string_duplicate(const char *str, const size_t length)
{
    if(str != NULL && length > 0) /*input validation*/
    {
        char *dup_array = malloc(length*sizeof(char));
        if(dup_array != NULL)
        {
            strncpy(dup_array, str, length); /*copy string into destination array*/
            //puts(dup_array);
            return dup_array;
        }
        else
        {
            return NULL;
        }

        
    }
    else
    {
        return NULL;
    }

}

bool string_equal(const char *str_a, const char *str_b, const size_t length)
{
    if(str_a != NULL && str_b != NULL && length > 0) /*input validation*/
    {
        int result = strncmp(str_a, str_b, length);
        if (result == 0)
        {
            //printf("strings are equal");
            return true;
        }
        else if (result > 0 || result < 0)
        {
            //printf("strings are NOT equal");
            return false;
        }
        else
        {
           // printf("something went wrong :(");
            return false;
        }
    }
    else
    {
        return false;
    }

}

int string_length(const char *str, const size_t length)
{

    if(str != NULL && length > 0) /*input validation*/
    {
        int i;
        int x = 0;
        for( i = 0; str[i] != '\0'; i++)
        {
            x++;
        }
        //printf("Size of string is %d", x);
        return x;
    }
    else
    {
        return -1;
    }

}

int string_tokenize(const char *str, const char *delims, const size_t str_length, char **tokens, const size_t max_token_length, const size_t requested_tokens)
{
    if(str != NULL && delims != NULL && str_length > 0 && tokens != NULL && max_token_length > 0 && requested_tokens > 0) /*input validation*/
    {
        int x;
        for(x = 0; x < requested_tokens; x++)
        {
            if(tokens[x] == NULL)
            {
                return -1;
            }
        }
        
        
        int i = 0;
        char *string = malloc(str_length * sizeof(char)); /*need string because str is const*/
        strcpy(string, str);
        char* temp = strtok(string, delims); /*first token into temp*/
        strcpy(tokens[i], temp);
        for(i = 1; i < requested_tokens; i++)
        {
            
            temp = strtok(NULL, delims);
            strcpy(tokens[i], temp);
            //printf("%s\n", tokens[i]);
        
            
        }
        free(string);
        return requested_tokens;
    }
    return 0;
}

bool string_to_int(const char *str, int *converted_value)
{
    if (str != NULL && converted_value != NULL)
    {
        long int result = strtol(str, NULL, 10);
        //printf("result is: %ld\n", result);
        if (result > 2147483647 || result < -2147483647) /*boundaries of int*/
        {
            return false;
        }
        else
        {
            *converted_value = result;
            return true;
        }
    }
    else
    {
        return false;
    }
}
