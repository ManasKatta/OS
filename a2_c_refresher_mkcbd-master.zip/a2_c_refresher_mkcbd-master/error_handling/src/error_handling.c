#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>



#include "../include/error_handling.h"

//yo
bool nameValid(char* string)
{
	if(strcmp(string, " ") == 0 || strcmp(string, "\n") == 0 || strcmp(string, "\t") == 0 || strcmp(string, "\r") == 0)
	{
		return false;
	}
	return true;
}

int create_blank_records(Record_t **records, const size_t num_records)
{
	if(*records == NULL && num_records > 0)
	{
		printf("\nGOT HERE\n");
		*records = (Record_t*) malloc(sizeof(Record_t) * num_records);
		if (*records == NULL)
		{
			return -2;
		}
		memset(*records,0,sizeof(Record_t) * num_records);
		return 0;	
	}
	return -1;

}


int read_records(const char *input_filename, Record_t *records, const size_t num_records) {

	if(input_filename != NULL && records != NULL && (int)num_records >0)
	{
		int fd = open(input_filename, O_RDONLY);
		if(fd < 0)
		{
			return -2;
		}

		ssize_t data_read = 0;
		for (size_t i = 0; i < num_records; ++i) {
			data_read = read(fd,&records[i], sizeof(Record_t));
			if(data_read <= 0 )
			{
				printf("\n\nGOT HERE\n\n");
				return -3;
			}	
		}
		return 0;
	}
	return -1;
}

int create_record(Record_t **new_record, const char* name, int age)
{
	if(*new_record == NULL && name != NULL && age > 1 && age < 200 && strlen(name) < 50 && nameValid((char*)name) == true )
	{
		*new_record = (Record_t*) malloc(sizeof(Record_t));
		if(*new_record == NULL)
		{
			return -2;
		}
		
		
		memcpy((*new_record)->name,name,sizeof(char) * strlen(name));
		(*new_record)->name[MAX_NAME_LEN - 1] = 0;	
		(*new_record)->age = age;
		return 0;
	}
	return -1;

}

