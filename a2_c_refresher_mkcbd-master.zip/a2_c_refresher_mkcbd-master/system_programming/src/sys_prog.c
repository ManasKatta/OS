#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "../include/sys_prog.h"
//this is random filler I added to make sure it pushed properly please ignore it
//hi
// LOOK INTO OPEN, READ, WRITE, CLOSE, FSTAT/STAT, LSEEK
// GOOGLE FOR ENDIANESS HELP

bool bulk_read(const char *input_filename, void *dst, const size_t offset, const size_t dst_size)
{
    if(input_filename != NULL && dst != NULL && dst_size > 0 && dst_size >= offset) /*input validation*/
    {
        int file = open(input_filename, O_RDONLY); 
        if(file < 0)
        {
            return false;
        }
        lseek(file, offset, SEEK_SET);
        size_t result = read(file, dst, dst_size);
        
        close(file);
        if(result <0)
        {
            return false;
        }
        return true;
    }
    return false;

}

bool bulk_write(const void *src, const char *output_filename, const size_t offset, const size_t src_size)
{
    if(output_filename != NULL && src != NULL && src_size > 0 )
    {
        int file = open(output_filename, O_WRONLY);
        if(file < 0)
        {
            return false;
        }
        lseek(file, offset, SEEK_SET);
        size_t result = write(file, src, src_size);
        
        
        close(file);
        if(result < 0)
        {
            return false;
        }
        return true;
    }

    return false;

}


bool file_stat(const char *query_filename, struct stat *metadata)
{
    if(query_filename != NULL && metadata != NULL)
    {
        int file = open(query_filename, O_RDONLY);
        if(file < 0)
        {
            return false;
        }
        size_t result = fstat(file, metadata);
        close(file);
        if(result < 0)
        {
            return false;
        }
        return true;
    }
    return false;

}

bool endianess_converter(uint32_t *src_data, uint32_t *dst_data, const size_t src_count)
{
    /*conversion method reference: https://stackoverflow.com/questions/2182002/convert-big-endian-to-little-endian-in-c-without-using-provided-func*/
    if(src_data != NULL && dst_data != NULL && src_count > 0) /*input validation*/
    {
        int i;
        for(i=0; i < src_count; i++)
        {
            uint32_t num = src_data[i];
            uint32_t swapped = ((num>>24)&0xff) | 
                      ((num<<8)&0xff0000) | 
                      ((num>>8)&0xff00) | 
                      ((num<<24)&0xff000000); 
            src_data[i] = swapped;
            dst_data[i] = src_data[i];
        
        }
        
        return true;
    }
    return false;
}

