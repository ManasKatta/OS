#include "../include/allocation.h"
#include <stdlib.h>
#include <stdio.h>


void* allocate_array(size_t member_size, size_t nmember,bool clear)
{
    if(member_size <= 0 || nmember <= 0)
    {
        return NULL;
    }
        void * array;
        if(clear == false)
        {
            array = malloc(nmember * member_size);
            // if(array == NULL)
            // {
            //     return NULL;
            // }
            return array;  
        }
        else
        {
            array = calloc(nmember, member_size);
            // if(array == NULL)
            // {
            //     return NULL;
            // }
            return array;  
        }

}

void* reallocate_array(void* ptr, size_t size)
{
    if(ptr != NULL && (int)size > 0)
    {
        void* array = realloc(ptr, size);
        if(array == NULL)
        {
            return NULL;
        }
        return array;
    }
    return NULL;
}

void deallocate_array(void** ptr)
{
    if(ptr != NULL && *ptr != NULL)
    {
        free(*ptr);
        *ptr = NULL;
    }
}

char* read_line_to_buffer(char* filename)
{
    if(filename != NULL)
    {
        FILE* fp = fopen(filename, "r");
        if(fp == NULL)
        {
            printf("fp failed\n");
            return NULL;
        }
        char* space = malloc(256 * sizeof(char));
        if(space == NULL)
        {
            printf("malloc failed\n");
            return NULL;
        }
        fgets(space, sizeof(space), fp);
        printf("hi\n");
        fclose(fp);
        return space;
    }
    return NULL;
}
