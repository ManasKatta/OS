#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "../include/arrays.h"

// LOOK INTO MEMCPY, MEMCMP, FREAD, and FWRITE

bool array_copy(const void *src, void *dst, const size_t elem_size, const size_t elem_count)
{
    if(src != NULL && dst != NULL && elem_size > 0 && elem_count > 0) /*input validation*/
    {
        memcpy(dst, src, elem_count*elem_size);
        //puts(dst);
        return true;
    }
    else
    {
        return false;
    }
}

bool array_is_equal(const void *data_one, void *data_two, const size_t elem_size, const size_t elem_count)
{
    if(data_one != NULL && data_two != NULL && elem_size > 0 && elem_count > 0) /*input validation*/
    {
        int result = memcmp(data_one, data_two, elem_count*elem_size); /*comparing the two data sets */
        if (result == 0)
        {
            //printf("arrays are equal");
            return true;
        }
        else if (result > 0 || result < 0)
        {
            //printf("arrays are NOT equal");
            return false;
        }
        else
        {
            //printf("something went wrong :(");
            return false;
        }
        
        return true;
    }
    else
    {
        return false;
    }

}

ssize_t array_locate(const void *data, const void *target, const size_t elem_size, const size_t elem_count)
{
    if(data != NULL && target != NULL && elem_size > 0 && elem_count > 0) /*input validation*/
    {
        int i;
        for (i=0; i<elem_count; i++)
        {
            
            if( ((int *)data)[i] == *(int*)target )
            {
               // printf("%2d is equal to %2d?", ((int *)data)[i], *(int *)target);
                return i;
            }

        }
        return -1;

    }
    return -1;
    

}

bool array_serialize(const void *src_data, const char *dst_file, const size_t elem_size, const size_t elem_count)
{
     if(src_data != NULL && dst_file != NULL && elem_size > 0 && elem_count > 0 && strcmp(dst_file, "") != 0 && strcmp(dst_file, "\n") != 0) /*input validation*/
     {
         FILE* fp = fopen(dst_file, "w");
         if(fp == NULL)
         {
             return false;
         }
         fwrite(src_data, elem_size, elem_count, fp);
         fclose(fp);
         return true;
     }
     else
     {
         return false;
     }


     

}

bool array_deserialize(const char *src_file, void *dst_data, const size_t elem_size, const size_t elem_count)
{
    if(src_file != NULL && dst_data != NULL && elem_size > 0 && elem_count > 0 && strcmp(src_file, "") != 0 && strcmp(src_file, "\n") != 0)
    {
        FILE* fp = fopen(src_file, "r");
        if(fp == NULL)
        {
            return false;
        }
        fread(dst_data, elem_size, elem_count, fp);
        fclose(fp);
        return true;
    }
    else
    {
        return false;  
    }
}
