Algorithm: FCFS
Average Turnaround Time: 192.77
Average Waiting Time: 179.20
Total Run Time: 407

real    0m2.542s
user    0m0.000s
sys     0m0.002s

Algorithm: RR
Average Turnaround Time: 220.20
Average Waiting Time: 206.63
Total Run Time: 407

real    0m2.253s
user    0m0.002s
sys     0m0.001s

Algorithm: SJF
Average Turnaround Time: 118.20
Average Waiting Time: 104.63
Total Run Time: 407

real    0m0.002s
user    0m0.002s
sys     0m0.000s

Algorithm: SRTF
Average Turnaround Time: 117.70
Average Waiting Time: 104.13
Total Run Time: 407

real    0m2.063s
user    0m0.001s
sys     0m0.001s