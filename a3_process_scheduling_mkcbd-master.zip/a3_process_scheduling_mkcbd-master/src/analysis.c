#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "dyn_array.h"
#include "processing_scheduling.h"

#define FCFS "FCFS"
#define P "P"
#define RR "RR"
#define SJF "SJF"
#define SRTF "SRTF"

// Add and comment your analysis code in this function.
// THIS IS FINISHED.
int main(int argc, char **argv) 
{
    
    if (argc < 3) 
    {
        printf("%s <pcb file> <schedule algorithm> [quantum]\n", argv[0]);
        return EXIT_FAILURE;
    }
    else 
    {

        dyn_array_t* rq = load_process_control_blocks(argv[1]);
        if(rq == NULL)
        {
            printf("PCB Loading Failed\n");
            return EXIT_FAILURE;
        }
        ScheduleResult_t* s = malloc(sizeof(ScheduleResult_t));
        if(s == NULL)
        {
            printf("Schedule Loading Failed\n");
            return EXIT_FAILURE;
        }
        memset(s,0,sizeof(ScheduleResult_t));

        if(strcmp(argv[2], FCFS) == 0)
        {
            //printf("\nFCFS requested\n");
            first_come_first_serve(rq, s);
        }
        if(strcmp(argv[2], SRTF) == 0)
        {
            //printf("\nSRTF requested\n");
            shortest_remaining_time_first(rq, s);
        }
        if(strcmp(argv[2], SJF) == 0)
        {
            //printf("\nSJF requested\n");
            shortest_job_first(rq, s);
        }
        if(strcmp(argv[2], RR) == 0)
        {
            //printf("\nRR requested\n");
            round_robin(rq, s, atoi(argv[3]));
        } 
       printf("\nAlgorithm: %s\nAverage Turnaround Time: %.2f\nAverage Waiting Time: %.2f\nTotal Run Time: %lu\n", argv[2], s->average_turnaround_time, s->average_waiting_time, s->total_run_time);
       
       free(s);
       dyn_array_destroy(rq);
    }

    
    
    return EXIT_SUCCESS;
}
