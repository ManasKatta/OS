#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "dyn_array.h"
#include "processing_scheduling.h"
//filler text

// You might find this handy.  I put it around unused parameters, but you should
// remove it before you submit. Just allows things to compile initially.
#define UNUSED(x) (void)(x)


int compare_arrivals(const void* pcba, const void* pcbb)
{
    if (((ProcessControlBlock_t*)pcba)->arrival > ((ProcessControlBlock_t*)pcbb)->arrival )
    {
        return -1;
    }
    else if (((ProcessControlBlock_t*)pcba)->arrival < ((ProcessControlBlock_t*)pcbb)->arrival )
    {
        return 1;
    }
    else
    {
        return 0;
    }
    return 0;
}
// private function
void virtual_cpu(ProcessControlBlock_t *process_control_block) 
{
    // decrement the burst time of the pcb
    --process_control_block->remaining_burst_time;
}


bool first_come_first_serve(dyn_array_t *ready_queue, ScheduleResult_t *result) 
{
    if(ready_queue == NULL || result == NULL)
    {
        printf("invalid parameters\n");
        return false;
    }
    dyn_array_sort(ready_queue, compare_arrivals);
    ProcessControlBlock_t pcb;
    float bursts = 0.0;
    int size = dyn_array_size(ready_queue);
    int i;
    for(i=0; i < size; i++)
    {
        dyn_array_extract_back(ready_queue, &pcb);
        bursts += pcb.remaining_burst_time;
        dyn_array_push_front(ready_queue, &pcb);
    }
    float counter=0;
    float total = 0.0;
    
    while(!dyn_array_empty(ready_queue))
    {
        dyn_array_extract_back(ready_queue, &pcb);
        while(pcb.remaining_burst_time != 0)
        {
            virtual_cpu(&pcb);
            counter++;
        }
        if(pcb.remaining_burst_time == 0)
        {
            total += counter - pcb.arrival;
            
        }
    }
    result->average_turnaround_time = total/size;
    result->average_waiting_time = (total-bursts)/size;
    result->total_run_time = bursts;
    
    return true;
}

bool shortest_job_first(dyn_array_t *ready_queue, ScheduleResult_t *result) 
{
    if(ready_queue == NULL || result == NULL)
    {
        printf("invalid parameters\n");
        return false;
    }
    ProcessControlBlock_t pcb;
    int size = dyn_array_size(ready_queue);
    float* arrivals = malloc(size * sizeof(float));
    float* bursts = malloc((size+1) * sizeof(float));
    float* temp = malloc(size * sizeof(float));
    float* wait = malloc(size * sizeof(float));
    float* tt = malloc(size * sizeof(float));
    float* completion = malloc(size * sizeof(float));
    float twt = 0;
    float totaltt = 0;
    float trt = 0;
    int i;
    int time;
    int smallest;
    for(i = 0; i < size; i++)
    {
        dyn_array_extract_back(ready_queue, &pcb);
        arrivals[i] = pcb.arrival;
        bursts[i] = pcb.remaining_burst_time;
        temp[i] = bursts[i];
        trt+= pcb.remaining_burst_time;
    }
    bursts[size] = 9999;
    for(time = 0; time < trt;)
    {
        smallest = size;
        for(i = 0; i< size; i++)
        {
            if(arrivals[i] <= time && bursts[i] > 0 && bursts[i] < bursts[smallest])
            {
                smallest = i;
            }
        }

        totaltt += time + bursts[smallest] - arrivals[smallest];
        twt += time - arrivals[smallest];
        time += bursts[smallest];
        bursts[smallest] = 0;
    }
    
    //printf("\nAWT: %.2f\nATT: %.2f\nTRT: %.2f\n", twt/size, totaltt/size, trt);

    result->average_turnaround_time = totaltt/size;
    result->average_waiting_time = twt/size;
    result->total_run_time = trt;


    free(arrivals);
    free(bursts);
    free(temp);
    free(wait);
    free(tt);
    free(completion);

    return true; 
}

bool priority(dyn_array_t *ready_queue, ScheduleResult_t *result) 
{
    UNUSED(ready_queue);
    UNUSED(result);
    return false;   
}


bool round_robin(dyn_array_t *ready_queue, ScheduleResult_t *result, size_t quantum) 
{
    if(ready_queue == NULL || result == NULL || quantum <= 0)
    {
        printf("invalid parameters\n");
        return false;
    }
    ProcessControlBlock_t pcb;
    ProcessControlBlock_t pcb2;
    int i;
    uint32_t x;
    float counter = 0;
    float total = 0;
    int size = dyn_array_size(ready_queue);
    dyn_array_t* q2 = dyn_array_create(size, sizeof(ProcessControlBlock_t), NULL);
    float trt = 0;
    for(i = 0; i < size; i++)
    {
        dyn_array_extract_back(ready_queue, &pcb);
        trt += pcb.remaining_burst_time;
        dyn_array_push_front(ready_queue, &pcb);
    }
   
   for( i = 0; i< size; i++)
   {
       dyn_array_extract_back(ready_queue, &pcb);
       if(pcb.arrival > counter)
       {
           dyn_array_push_back(q2, &pcb);
       }
       else
       {
           dyn_array_push_front(ready_queue, &pcb);
       }
   }

    while(!dyn_array_empty(ready_queue))
    {
        
        dyn_array_extract_back(ready_queue, &pcb);
        
        for(x = 0; x < quantum; x++)
        {
            virtual_cpu(&pcb);
            counter++;
           
            int qsize = dyn_array_size(q2);
            for(i = 0; i < qsize; i++)
            {
                dyn_array_extract_back(q2, &pcb2);
                if(pcb2.arrival <= counter)
                {
                    dyn_array_push_front(ready_queue, &pcb2);
                }
                else
                {
                    dyn_array_push_front(q2, &pcb2);
                }

            }
            
            if(pcb.remaining_burst_time == 0)
            {
                break;
            }
        }

        if(pcb.remaining_burst_time == 0)
        {
            total += counter - pcb.arrival;
            
        }
        else
        {
            dyn_array_push_front(ready_queue, &pcb);
        }

    }
    
    //printf("\nTOTAL TT: %.2f\nTOTAL WAIT: %.2f\n", total, total - trt);
    result->average_turnaround_time = total/size;
    result->average_waiting_time = (total-trt)/size;
    result->total_run_time = trt;
   
    
   


    // free(temp);
    // free(arrival_times);
    // free(burst_times);
    dyn_array_destroy(q2);
    return true;
}

dyn_array_t *load_process_control_blocks(const char *input_file) 
{
    
    if(input_file == NULL || strcmp(input_file, ".bin") == 0)
    {
        printf("invalid file\n");
        return NULL;
    }

    int fd = open(input_file, O_RDONLY);
    if(fd <= 0)
    {
        printf("file opening failed\n");
        close(fd);
        return NULL;
    }
    uint32_t n;
    int size = read(fd, &n, sizeof(uint32_t));
    if(size <=0)
    {
        printf("something went wrong :(\n");
        return NULL;
    }

    ProcessControlBlock_t * pcbs = malloc(n * sizeof(ProcessControlBlock_t));
    if(pcbs == NULL)
    {
        printf("pcb allocation failed\n");
        return NULL;
    }
    int result;
    for(uint32_t i = 0; i < n; i++)
    {
        result = read(fd, &pcbs[i].remaining_burst_time, sizeof(uint32_t));
        result = read(fd, &pcbs[i].priority, sizeof(uint32_t));
        result = read(fd, &pcbs[i].arrival, sizeof(uint32_t));
        if(result <=0)
        {
            printf("something went wrong when reading\n");
            free(pcbs);
            return NULL;
        } 
    }

    dyn_array_t* dry = dyn_array_import((void*)pcbs, n, sizeof(ProcessControlBlock_t), NULL);

    close(fd);
    free(pcbs);
    return dry;




}


//SRTF Algorithm: https://cppsecrets.com/users/130697109105116981051151041169798575364103109971051084699111109/C00-Program-of-Shortest-Remaining-Time-FirstSRTF-Scheduling.php
bool shortest_remaining_time_first(dyn_array_t *ready_queue, ScheduleResult_t *result) 
{
    if(ready_queue == NULL || result == NULL)
    {
        printf("invalid parameters\n");
        return false;
    }
    ProcessControlBlock_t pcb;
    int size = dyn_array_size(ready_queue);
    float* arrivals = malloc(size * sizeof(float));
    float* bursts = malloc((size+1) * sizeof(float));
    float* temp = malloc(size * sizeof(float));
    float* wait = malloc(size * sizeof(float));
    float* tt = malloc(size * sizeof(float));
    float* completion = malloc(size * sizeof(float));
    float twt=0.0;
    float totaltt=0.0;
    float end=0.0;
    float trt=0.0;
    int i;
    int time;
    int smallest;
    int count=0;
    for(i = 0; i < size; i++)
    {
        dyn_array_extract_back(ready_queue, &pcb);
        arrivals[i] = pcb.arrival;
        bursts[i] = pcb.remaining_burst_time;
        temp[i] = bursts[i];
        trt+= pcb.remaining_burst_time;
    }
    bursts[size] = 9999;
    for(time = 0; count != size; time++)
    {
        smallest = size;
        for(i = 0; i<size; i++)
        {
            if(arrivals[i] <= time && bursts[i] < bursts[smallest] && bursts[i] > 0 )
            {
                smallest = i;
            }
        }
        bursts[smallest]--;

        if(bursts[smallest] == 0)
        {
            count++;
            end = time+1;
            completion[smallest] = end;
            wait[smallest] = end - arrivals[smallest] - temp[smallest];
            tt[smallest]= end - arrivals[smallest];
           
        }
    }

    for(i = 0; i<size; i++)
    {
        twt = twt + wait[i];
        totaltt = totaltt + tt[i];
    }


    //printf("\nAWT: %.2f\nATT: %.2f\nTRT: %.2f", twt/size, totaltt/size, trt);

    result->average_turnaround_time = totaltt/size;
    result->average_waiting_time = twt/size;
    result->total_run_time = trt;


    free(arrivals);
    free(bursts);
    free(temp);
    free(wait);
    free(tt);
    free(completion);

    return true;
}





