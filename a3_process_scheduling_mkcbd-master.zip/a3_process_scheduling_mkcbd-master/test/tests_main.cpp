// Using a C library requires extern "C" to prevent function managling
extern "C" 
{
#include <dyn_array.h>
}

unsigned int score;
unsigned int total;

