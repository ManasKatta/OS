#include <stdio.h>
#include <stdint.h>
#include "bitmap.h"
#include "block_store.h"
// include more if you need
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

// You might find this handy.  I put it around unused parameters, but you should
// remove it before you submit. Just allows things to compile initially.
#define UNUSED(x) (void)(x)
//filler text

struct block_store
{
    char* data[BLOCK_STORE_NUM_BLOCKS][BLOCK_SIZE_BYTES];
    bitmap_t* bitmap;
};

block_store_t* block_store_create()
{
    block_store_t* bs = calloc(1,sizeof(block_store_t));
    if(bs == NULL)
    {
        printf("Malloc failed\n");
        return NULL;
    }
    bs->bitmap = bitmap_overlay(BITMAP_SIZE_BITS, bs->data);
    bitmap_set(bs->bitmap, 127); //set the spots occupied by the bitmap
    bitmap_set(bs->bitmap, 128);
   
    
    
    return bs;
}

void block_store_destroy(block_store_t *const bs)
{
    if(bs == NULL || bs->bitmap == NULL)
    {
        return;
    }
    bitmap_destroy(bs->bitmap);
    free(bs);

    
    
}
size_t block_store_allocate(block_store_t *const bs)
{
    if(bs == NULL || bs->data == NULL || bs->bitmap == NULL)
    {
        return SIZE_MAX;
    }
    size_t firstFree = bitmap_ffz(bs->bitmap); //find first free spot
    if(firstFree >= SIZE_MAX || firstFree > BLOCK_STORE_NUM_BLOCKS)
    {
        return SIZE_MAX;
    }
    bitmap_set(bs->bitmap, firstFree);
    return firstFree;
}

bool block_store_request(block_store_t *const bs, const size_t block_id)
{
    if(bs == NULL)
    {
        printf("\nbs is null\n");
        return false;
    }
    if(block_id > BLOCK_STORE_NUM_BLOCKS)
    {
        printf("\ninvalid size\n");
        return false;
    }
    if(bs->bitmap == NULL)
    {
        printf("\nbs bitmap is null\n");
        return false;
    }
    if( bitmap_test(bs->bitmap, block_id) == true)
    {
        printf("\nbit is already set\n");
        return false;
    }
    
    bitmap_set(bs->bitmap, block_id);

    if(bitmap_test(bs->bitmap, block_id) == 0)
    {
        printf("\nMade it to the second error check\n");
        return false;
    }
    return true;
}

void block_store_release(block_store_t *const bs, const size_t block_id)
{
    if(bs != NULL && bs->bitmap != NULL)
    {
        bitmap_reset(bs->bitmap, block_id);
    }
}

size_t block_store_get_used_blocks(const block_store_t *const bs)
{
    if(bs != NULL && bs->bitmap != NULL)
    {
        return bitmap_total_set(bs->bitmap);
    }
    return SIZE_MAX;
}

size_t block_store_get_free_blocks(const block_store_t *const bs)
{
    if(bs != NULL && bs->bitmap != NULL)
    {
        return BLOCK_STORE_NUM_BLOCKS - bitmap_total_set(bs->bitmap);
    }
    return SIZE_MAX;
}

size_t block_store_get_total_blocks()
{
    return BLOCK_STORE_NUM_BLOCKS;
}

size_t block_store_read(const block_store_t *const bs, const size_t block_id, void *buffer)
{
    if(bs == NULL || buffer == NULL)
    {
        return 0;
    }
    memcpy(buffer, bs->data[block_id], BLOCK_SIZE_BYTES);
    return BLOCK_SIZE_BYTES;
}

size_t block_store_write(block_store_t *const bs, const size_t block_id, const void *buffer)
{
    if(bs == NULL || buffer == NULL)
    {
        return 0;
    }
    memcpy(bs->data[block_id], buffer, BLOCK_SIZE_BYTES);
    return BLOCK_SIZE_BYTES;
    return 0;
}

block_store_t *block_store_deserialize(const char *const filename)
{
    if(filename == NULL)
    {
        printf("\nplease enter a valid filename\n");
        return NULL;
    }
    int fd = open(filename, O_RDONLY);
    if(fd < 0)
    {
        
        perror("\nFile opening failed");
        printf("\n");
        return NULL;
    }

    block_store_t* bs = calloc(1, sizeof(block_store_t));
    int result = read(fd, bs, BLOCK_STORE_NUM_BYTES); //read the data into the block store
    if(result < 0)
    {
        perror("\nbitmap reading failed");
        return NULL;
    }
    bs->bitmap = bitmap_import(BITMAP_SIZE_BITS, bs->data);
    close(fd);
    return bs;

}

size_t block_store_serialize(const block_store_t *const bs, const char *const filename)
{
    if(bs == NULL || filename == NULL)
    {
        return 0;
    }

    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0777);
    if(fd < 0)
    {
        
        perror("\nFile opening failed");
        printf("\n");
        return 0;
    }

    int result = write(fd, bs, BLOCK_STORE_NUM_BYTES);
    if(result < 0 )
    {
        perror("\nFile writing failed");
        return 0;
    }
    close(fd);

    return result;
}